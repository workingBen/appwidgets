package com.mobitv.sprint.tvwidget;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.IntentService;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.widget.RemoteViews;

public class SprintTvAppWidget extends AppWidgetProvider {
	
	/*
	 * TODO: 
	 * * CHECK WHAT HAPPENS IF TILE IS NOT THERE, FAIL GRACEFULLY
	 * * CHECK WHAT HAPPENS WHEN TILE SERVER IS DOWN, FAIL GRACEFULLY
	 * * GET TILE SIZE DYNAMICALLY
	 * * GET PROPERTIES FROM SKU FILES
	 * * REDO SKIN
	 * * MAKE CONFIG ACTION
	 * * HOOK UP BUTTONS TO CONFIG ACTION AND FORWARD, BACK FOR MARKETING TILES
	 * * SUPPORT hdpi, mdpi, ldpi
	 * * MAKE deep links work for browse and stream
	 * * CONSTRUCT or GET marketing tile plist URL in same way the app does it
	 */
	
	private static final String identifier = "SprintTvAppWidget";	
	static Context mycontext;
	
	public static final String INTENT_TYPE = "intent_type";
	public static final int INTENT_PREV = 1;
	public static final int INTENT_NEXT = 2;
	public static final int INTENT_REFRESH = 3;
	
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, final int[] appWidgetIds) {
		Log.v(identifier, "@@@ ******************* Updating Sprint TV widget ***********************");
		// why is appWidgetIds > 1
		for ( int i = 0; i < appWidgetIds.length; ++i ) {
			final int id = appWidgetIds[i];
			Intent intent = new Intent(context, UpdateService.class);
			intent.setData(Uri.parse(String.valueOf(id)));
			Log.v(identifier, "@@@ ???????????? :::BLANK INTENT 1::: id = " + String.valueOf(id) + "i=" + i);
			context.startService(intent);
		}			
		mycontext = context;
	}
	
	@Override
	public void onReceive(Context ctxt, Intent intent) {
		Bundle extras = intent.getExtras();
		int type = extras != null ? extras.getInt(INTENT_TYPE) : 0;
		final String action = intent.getAction();
		
		if ( type == INTENT_PREV || type == INTENT_PREV || type == INTENT_REFRESH ) {
			Intent prevNextIntent = new Intent(ctxt, UpdateService.class);
			prevNextIntent.putExtra(INTENT_TYPE, type);
			ctxt.startService(prevNextIntent);
		} else if (AppWidgetManager.ACTION_APPWIDGET_DELETED.equals(action)) { // v1.5 fix that doesn't call onDelete Action 
			final int appWidgetId = intent.getExtras().getInt( AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID); 
			if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) { 
				this.onDeleted(ctxt, new int[] { appWidgetId }); 
			}
		} else {
			Log.v(identifier, "@@@ ???????????? :::questionable (maybe blank) INTENT 3::: STARTING NEW SERVICE");
			super.onReceive(ctxt, intent);
		}
	}	
	
	static class Path {
		public String id;
		public String name;				
		
		public String toString() {
			return "id: " + id + " name: " + name;
		}		
	}
	public static Boolean processingPathKey = false;
	
	// hold info for a marketing tile
	static class MarketingTile {
		public String id;
		public int number;
		public String media_type;
		public Boolean has_program_data;
		public ArrayList<String> packages;
		public String name;
		public String description;
		public String duration;
		public String media_id;
		public String media_class;
		public String network;
		public String media_aspect_ratio;
		public ArrayList<String> media_restrictions;
		public Boolean visible;
		public String tile_id;
		public String campaign_id;
		public Path path;		
		public Bitmap image;
		
		public MarketingTile() {
			// create blank tile
			this.packages = new ArrayList<String>();
			this.media_restrictions = new ArrayList<String>();
			this.path = new Path();
			this.image = null;
		}
		
		public MarketingTile(String id, int number, String media_type, Boolean has_program_data, ArrayList<String> packages, String name, 
				String description, String duration, String media_id, String media_class, String network, String media_aspect_ratio, 
				ArrayList<String> media_restrictions, Boolean visible, String tile_id, String campaign_id, Path path) {
			this.id = id;
			this.number = number;
			this.media_type = media_type;
			this.has_program_data = has_program_data;
			this.packages = packages;
			this.name = name;
			this.description = description;
			this.duration = duration;
			this.media_id = media_id;
			this.media_class = media_class;
			this.network = network;
			this.media_aspect_ratio = media_aspect_ratio;
			this.media_restrictions = media_restrictions;
			this.visible = visible;
			this.tile_id = tile_id;
			this.campaign_id = campaign_id;
			this.path = path;
			this.image = null;
		}
		
		public String url() {
			return "sprinttv:";
		}
		
		public void printTile() {
			Log.v(identifier, "PRINTING TILE INFORMATION");
			Log.v(identifier, "TILE.id=" + this.id);
			Log.v(identifier, "TILE.number=" + this.number);
			Log.v(identifier, "TILE.media_type=" + this.media_type);
			Log.v(identifier, "TILE.has_program_data=" + this.has_program_data);
			Log.v(identifier, "TILE.packages=" + this.packages.toString());
			Log.v(identifier, "TILE.name=" + this.name);
			Log.v(identifier, "TILE.description=" + this.description);
			Log.v(identifier, "TILE.duration=" + this.duration);
			Log.v(identifier, "TILE.media_id=" + this.media_id);
			Log.v(identifier, "TILE.media_class=" + this.media_class);
			Log.v(identifier, "TILE.network=" + this.network);
			Log.v(identifier, "TILE.media_aspect_ratio=" + this.media_aspect_ratio);
			Log.v(identifier, "TILE.media_restrictions=" + this.media_restrictions.toString());
			Log.v(identifier, "TILE.visible=" + this.visible);
			Log.v(identifier, "TILE.tile_id=" + this.tile_id);
			Log.v(identifier, "TILE.campaign_id=" + this.campaign_id);
			Log.v(identifier, "TILE.path=" + this.path);
		}
	}
	
	public static MarketingTile getNextMarketingTile() {	
		if ( tiles != null && tiles.size() > 0 ) {
			marketingTileIndex = (marketingTileIndex + 1) % tiles.size();
			return tiles.get(marketingTileIndex);
		}
		return null;
	}
	
	public static MarketingTile getPrevMarketingTile() {	
		if ( tiles != null && tiles.size() > 0 ) {
			marketingTileIndex = marketingTileIndex - 1;
			marketingTileIndex = marketingTileIndex < 0 ? 0 : marketingTileIndex;
			return tiles.get(marketingTileIndex);
		}
		return null;
	}	
	
	public static MarketingTile getCurrentMarketingTile() {	
		if ( tiles != null && tiles.size() > 0 ) {
			marketingTileIndex = marketingTileIndex < 0 ? 0 : marketingTileIndex;
			return tiles.get(marketingTileIndex);
		}
		return null;
	}		
	public static ArrayList<MarketingTile> tiles;
	public static int marketingTileIndex = -1;
	
	public static class UpdateService extends IntentService {

		public UpdateService() {
			super("SprintTvAppWidget$UpdateService");
		}
		
		@Override
		public void onHandleIntent(Intent intent) {
			Log.v(identifier, "@@@ ************HANDLING INTENT************");
			buildUpdate(null, null);
		}
		
		private void buildUpdate(Intent intent, Integer startId) {			
			ComponentName me=new ComponentName(this, SprintTvAppWidget.class);
			AppWidgetManager mgr=AppWidgetManager.getInstance(this);
			mgr.updateAppWidget(me, updateDisplay(intent, startId));
			
			if (startId != null) {
				stopSelfResult(startId);
			}			
//			mgr.updateAppWidget(Integer.parseInt(intent.getDataString()), updateViews);
//			Log.v(identifier, "Sprint TV widget updated");
		}
		
		private RemoteViews updateDisplay(Intent intent, Integer startId) {
			Log.v(identifier, "@@@ ************UPDATING DISPLAY************");
			
			RemoteViews views = new RemoteViews(getPackageName(), R.layout.appwidget);
			MarketingTile tile;
			
			Bundle extras = intent.getExtras();
			int type = extras != null ? extras.getInt(INTENT_TYPE) : 0;
			if ( type == INTENT_PREV ) {
				tile = getNextMarketingTile();
			} else if ( type == INTENT_PREV ) {
				tile = getPrevMarketingTile();
			} else {
				tile = getCurrentMarketingTile();
			}									
			
			Intent sprintTvIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("sprinttv:"));
			sprintTvIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			PendingIntent mainAction = PendingIntent.getActivity(this, 0, sprintTvIntent, 0);
			views.setOnClickPendingIntent(R.id.appwidget_logo, mainAction);
			
			SpannableStringBuilder text = new SpannableStringBuilder();
			if ( tile != null ) {
				text.append(tile.name);
				if ( tile.description != null && tile.description.length() > 0 ) {
					text.append('\n');
					text.append(tile.description);
				}
				
				text.setSpan(new AbsoluteSizeSpan(12, true), 0, text.length(), 0);
				text.setSpan(new StyleSpan(Typeface.BOLD), 0, tile.name.length(), 0);
				
				Intent featuredIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(tile.url()));
				featuredIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				PendingIntent featuredAction = PendingIntent.getActivity(this, 0, featuredIntent, 0);
				views.setOnClickPendingIntent(R.id.appwidget_item, featuredAction);
			} else {
				String title = getString(R.string.default_label);
				
				text.append(title);
				text.append('\n');
				text.append(getString(R.string.default_description));
				
				text.setSpan(new AbsoluteSizeSpan(12, true), 0, text.length(), 0);
				text.setSpan(new StyleSpan(Typeface.BOLD), 0, title.length(), 0);
				
				views.setOnClickPendingIntent(R.id.appwidget_item, mainAction);
			}
			views.setTextViewText(R.id.appwidget_item, text);	
				
			// set image to next image
			Bitmap nextImage;
			if ( tile.image == null ) {
				nextImage = downloadFile(getImageURL(tile));
				if ( nextImage != null ) {
					tile.image = nextImage;		
					views.setImageViewBitmap(R.id.appwidget_tile, tile.image);
				} else {					
					views.setImageViewResource(R.id.appwidget_tile, R.drawable.tile_default);
				}
			} else {
				views.setImageViewBitmap(R.id.appwidget_tile, tile.image);
			}
			
			
			Intent prevIntent=new Intent(this, SprintTvAppWidget.class);
			prevIntent.putExtra(INTENT_TYPE, INTENT_PREV);
			PendingIntent pendingPrevIntent=PendingIntent.getBroadcast(this, 0, prevIntent, 0);				
			views.setOnClickPendingIntent(R.id.appwidget_prev, pendingPrevIntent);
			
			Intent nextIntent=new Intent(this, SprintTvAppWidget.class);
			nextIntent.putExtra(INTENT_TYPE, INTENT_NEXT);
			PendingIntent pendingNextIntent=PendingIntent.getBroadcast(this, 0, nextIntent, 0);				
			views.setOnClickPendingIntent(R.id.appwidget_next, pendingNextIntent);		
			
			Intent refreshIntent=new Intent(this, SprintTvAppWidget.class);
			refreshIntent.putExtra(INTENT_TYPE, INTENT_REFRESH);
			PendingIntent pendingRefreshIntent=PendingIntent.getBroadcast(this, 0, refreshIntent, 0);				
			views.setOnClickPendingIntent(R.id.appwidget_refresh, pendingRefreshIntent);
			
            return views;
		}
		
		//TODO: dont hardcode TILE_HOST or TILE_DARK, get it from a SKU file 
		String TILE_HOST = "http://tmobile.rest.mobitv.com/guide/v3/icon/tmobile/mobitv_3pg/4.0/tile/";
		Boolean TILE_DARK = true;
		//TODO: get this from screen dimensions and figure it out dynamically
		String TILE_SIZE = "300x400";
		
		String getImageURL(MarketingTile tile) {
			String tileUrl = null;
			String TILE_SHADE = TILE_DARK ? ".dark" : ".light";
			tileUrl = TILE_HOST + tile.tile_id + "/" + TILE_SIZE + TILE_SHADE + ".png";
			return tileUrl;
		}
		
		Bitmap downloadFile(String fileUrl) {
			Bitmap bmImg = null;
			URL myFileUrl = null;
			try {
				myFileUrl = new URL(fileUrl);
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				HttpURLConnection conn = (HttpURLConnection)myFileUrl.openConnection();
				conn.setDoInput(true);
//				int length = conn.getContentLength();
//				int[] bitmapData = new int[length];
//				byte[] bitmapData2 = new byte[length];
				InputStream is = conn.getInputStream();
				
				bmImg = BitmapFactory.decodeStream(is);
			} catch(IOException e) {
				e.printStackTrace();
			}
			return bmImg;
		}
		
		@Override
		public void onStart(final Intent intent, final int startId) {
			final Runnable updateUI = new Runnable(){
				public void run(){
					Log.v(identifier, "@@@ RUNNING TV WIDGET onStart()");
					
					Bundle extras = intent.getExtras();
					int type = extras != null ? extras.getInt(INTENT_TYPE) : 0;
					if ( type == INTENT_PREV || type == INTENT_PREV ) {
						Log.v(identifier, "@@@ $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ prev / next $$$$$$$$$$$$$$");
						buildUpdate(intent, startId);
					} else {
						Log.v(identifier, "@@@ $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ refresh plist $$$$$$$$$$$$$$");
						String serverUrl = getString(R.string.url_plist);
						try {
							tiles = new ArrayList<MarketingTile>();
							Log.v(identifier, "@@@ Retrieving featured channel from "+serverUrl);
							URL featuredContentUrl = new URL(serverUrl);
							HttpURLConnection httpconn = (HttpURLConnection)featuredContentUrl.openConnection();
							httpconn.connect();
							try {
								XmlPullParserFactory xppfactory = XmlPullParserFactory.newInstance();
								XmlPullParser xpp = xppfactory.newPullParser();
								xpp.setInput(httpconn.getInputStream(), "UTF-8");
	
								int event = xpp.getEventType();
								while ( event != XmlPullParser.END_DOCUMENT ) {
									switch (event) {
									case XmlPullParser.START_TAG:
										String tagName = xpp.getName();
										if ( "plist".equalsIgnoreCase(tagName) ) {										
											event = xpp.next(); // do nothing, we throw away the plist wrapper and array wrapper
											if ( "array".equalsIgnoreCase(xpp.getName()) ) {
												event = xpp.next(); // do nothing, throw away array (of dictionaries) tag											
											}
										} else if ( "dict".equalsIgnoreCase(tagName) ) {
											tiles.add(parseMarketingTile(xpp));
										}
										break;
	
									case XmlPullParser.END_TAG:
										break;
	
									default:
										break;
									}
									event = xpp.next();
								}
							} catch ( Exception e ) {
								Log.e(identifier, "exception occurred while parsing xml", e);
							}
							finally {
								httpconn.disconnect();
							}
						} catch (Exception ioe) {
							Log.e(identifier, "network error", ioe);
						}					
						buildUpdate(intent, startId);
					}
				}
			};		
			ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
			if( cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected() ){
				new Thread(updateUI).start();
			}
			else{
				BroadcastReceiver networkChange = new BroadcastReceiver(){
					@Override
					public void onReceive(Context context, Intent intent) {
						try{
							NetworkInfo ni = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
							if(ni != null && ni.isConnected()){
								new Thread(updateUI).start();
								UpdateService.this.unregisterReceiver(this); 
							}
						}catch( Exception e ){
							Log.e(identifier, "receiver error", e);
						}
					}
				};
				registerReceiver(networkChange, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
			}
		}
		
		public MarketingTile parseMarketingTile(XmlPullParser xpp) throws XmlPullParserException {
			Log.v(identifier, "@@@ PARSING XML TILE");
			MarketingTile tile = new MarketingTile();
			String currentKeyType = null;
			while(true) {
				try {
					int eventType = xpp.getEventType();
					if (eventType == XmlPullParser.START_TAG) {
						String tagName = xpp.getName();
						if ( "key".equalsIgnoreCase(tagName) ) {
							currentKeyType = xpp.nextText();
							if ( "path".equalsIgnoreCase(currentKeyType) ) {
								processingPathKey = true;
							}
						} else if ( "string".equalsIgnoreCase(tagName) ) {
							if ( "id".equalsIgnoreCase(currentKeyType) ) {
								if ( processingPathKey == true ) {
									tile.path.id = xpp.nextText();
								} else {
									tile.id = xpp.nextText();
								}
							} else if ( "media_type".equalsIgnoreCase(currentKeyType) ) {
								tile.media_type = xpp.nextText();
							} else if ( "packages".equalsIgnoreCase(currentKeyType) ) {
								tile.packages.add(xpp.nextText());
							} else if ( "name".equalsIgnoreCase(currentKeyType) ) {
								if ( processingPathKey == true ) {
									tile.path.name = xpp.nextText();
								} else {
									tile.name = xpp.nextText();
								}
							} else if ( "description".equalsIgnoreCase(currentKeyType) ) {
								tile.description = xpp.nextText();
							} else if ( "duration".equalsIgnoreCase(currentKeyType) ) {
								tile.duration = xpp.nextText();
							} else if ( "media_id".equalsIgnoreCase(currentKeyType) ) {
								tile.media_id = xpp.nextText();
							} else if ( "media_class".equalsIgnoreCase(currentKeyType) ) {
								tile.media_class = xpp.nextText();
							} else if ( "network".equalsIgnoreCase(currentKeyType) ) {
								tile.network = xpp.nextText();
							} else if ( "media_aspect_ratio".equalsIgnoreCase(currentKeyType) ) {
								tile.media_aspect_ratio = xpp.nextText();
							} else if ( "media_restrictions".equalsIgnoreCase(currentKeyType) ) {
								tile.media_restrictions.add(xpp.nextText());
							} else if ( "tile_id".equalsIgnoreCase(currentKeyType) ) {
								tile.tile_id = xpp.nextText();
							} else if ( "campaign_id".equalsIgnoreCase(currentKeyType) ) {
								tile.campaign_id = xpp.nextText();
							}
						} else if ( "array".equalsIgnoreCase(currentKeyType) ) {
							// ignore array tags
						} else if ( "integer".equalsIgnoreCase(currentKeyType) ) {
							if ( "number".equalsIgnoreCase(currentKeyType) ) {
								tile.number = Integer.parseInt(xpp.nextText());
							} 
						} else if ( "".equalsIgnoreCase(currentKeyType) ) {
							
						}
					} else if ( eventType == XmlPullParser.END_TAG ) {
						if ( "dict".equalsIgnoreCase(xpp.getName()) ) {
							if ( processingPathKey ) { // make sure to set processingPathKey when starting and finishing path
								processingPathKey = false;
							} else {
								break;
							}
						} else if ( "true".equalsIgnoreCase(xpp.getName()) ) {
							// TODO: HOW IS HAS PROGRAM DATA and VISIBLE FALSE REPRESENTED??? ABSENSE OR FALSE?
							if ( "has_program_data".equalsIgnoreCase(currentKeyType) ) {
								tile.has_program_data = true;
							} else if ( "visible".equalsIgnoreCase(currentKeyType) ) {
								tile.visible = true;
							}
						} else if ( "false".equalsIgnoreCase(xpp.getName()) ) {
							// TODO: HOW IS HAS PROGRAM DATA and VISIBLE FALSE REPRESENTED??? ABSENSE OR FALSE?
							if ( "has_program_data".equalsIgnoreCase(currentKeyType) ) {
								tile.has_program_data = false;
							} else if ( "visible".equalsIgnoreCase(currentKeyType) ) {
								tile.visible = false;
							}
						}
					}
					xpp.next();
				} catch(IOException ioe) {
					ioe.printStackTrace();
				}				
			}			
			//tile.printTile();
			return tile;
		}
		
		@Override
		public IBinder onBind(Intent intent) {
			return null;
		}
	}
}
